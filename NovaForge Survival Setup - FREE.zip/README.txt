 ________  ________   _____      _               
/  ___|  \/  | ___ \ /  ___|    | |              
\ `--.| .  . | |_/ / \ `--.  ___| |_ _   _ _ __  
 `--. | |\/| |  __/   `--. \/ _ | __| | | | '_ \ 
/\__/ | |  | | |     /\__/ |  __| |_| |_| | |_) |
\____/\_|  |_\_|     \____/ \___|\__|\__,_| .__/ 
                                          | |    
                                          |_|    

______                          _                 _          
|  _  \                        | |               (_)         
| | | |___ _ __   ___ _ __   __| | ___ _ __   ___ _  ___ ___ 
| | | / _ | '_ \ / _ | '_ \ / _` |/ _ | '_ \ / __| |/ _ / __|
| |/ |  __| |_) |  __| | | | (_| |  __| | | | (__| |  __\__ \
|___/ \___| .__/ \___|_| |_|\__,_|\___|_| |_|\___|_|\___|___/
          | |                                                
          |_|                                                

You need these to run the server:

Citizens - 
  Free: https://ci.citizensnpcs.co/job/citizens2/
  Paid: https://www.spigotmc.org/resources/citizens.13811/

TAB -
  Free: https://www.spigotmc.org/resources/tab-1-5-1-20-4.57806/

 _____                              _   
/  ___|                            | |  
\ `--. _   _ _ __  _ __   ___  _ __| |_ 
 `--. | | | | '_ \| '_ \ / _ \| '__| __|
/\__/ | |_| | |_) | |_) | (_) | |  | |_ 
\____/ \__,_| .__/| .__/ \___/|_|   \__|
            | |   | |                   
            |_|   |_|                   

We have multiple ways to support you in getting the server up and running.

Checkout our Discord and make a ticket:
https://discord.gg/pSAmacwx42

Check out the documentation:
https://docs.novaforgestudios.com/